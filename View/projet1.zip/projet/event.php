<!DOCTYPE html>
<?php
session_start();

require_once "../../config/database.php";

require_once '../../controllers/eventcontroller.php';
$conn = config::getConnexion();
/*if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit();
}*/
$id_client = $_SESSION['id_user']?? 1; // Default to 1 if not set
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
   <style>
    .container{
  max-width: 1200px;
  margin: 0 auto;
  text-align: center;
  padding:25px 20px;
}

.container .heading{
  font-size: 40px;
  margin-bottom: 20px;
  color:#334;
}

.container .box-container{
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap:20px;
}

.container .box-container .box{
  background-color: #fff;
  padding:20px;
  border-radius: 5px;
  box-shadow: 0 5px 10px rgba(0,0,0,.2);
  display: none;
}

.container .box-container .box:nth-child(1),
.container .box-container .box:nth-child(2),
.container .box-container .box:nth-child(3){
  display: inline-block;
}

.container .box-container .box .image{
  margin-bottom: 20px;
  overflow: hidden;
  height: 250px;
  border-radius: 5px;
}

.container .box-container .box .image img{
  height: 100%;
  width: 100%;
  object-fit: cover;
}

.container .box-container .box:hover .image img{
  transform: scale(1.1);
}

.container .box-container .box .content h3{
  font-size: 20px;
  color:#334;
}

.container .box-container .box .content p{
  font-size: 15px;
  color:#777;
  line-height: 2;
  padding:15px 0;
}

.container .box-container .box .content .btn{
  display: inline-block;
  padding:10px 30px;
  border:1px solid #334;
  color:#334;
  font-size: 16px;
}

.container .box-container .box .content .btn:hover{
  background-color: crimson;
  border-color: crimson;
  color:#fff;
}

.container .box-container .box .content .icons{
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 20px;
  padding-top: 15px;
  border-top:1px solid #334;
}

.container .box-container .box .content .icons span{
  font-size: 14px;
  color:#777;
}

.container .box-container .box .content .icons span i{
  color:crimson;
  padding-right: 5px;
}

#load-more{
  margin-top: 20px;
  display: inline-block;
  padding:13px 30px;
  border:1px solid #334;
  color:#334;
  font-size: 16px;
  background-color: #fff;
  cursor: pointer;
}

#load-more:hover{
  background-color: crimson;
  border-color: crimson;
  color:#fff;
}

@media (max-width:450px){

  .container .heading{
    font-size: 25px;
  }

  .container .box-container{
    grid-template-columns: 1fr;
  }

  .container .box-container .box .image{
    height: 200px;
  }

  .container .box-container .box .content p{
    font-size: 12px;
  }

  .container .box-container .box .content .icons span{
    font-size: 12px;
  }

}
.box-container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  align-items: flex-start; /* Prevent equal height boxes */
}

.box {
  flex: 0 1 300px;
  border: 1px solid #ccc;
  padding: 15px;
  box-sizing: border-box;
  transition: all 0.3s ease;
  position: relative;
}

.event-details {
  display: none;
  margin-top: 10px;
  background-color: #f9f9f9;
  padding: 10px;
  border-top: 1px solid #ccc;
}

.event-details.visible {
  display: block;
}



</style>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.min.js" integrity="sha384-VQqxDN0EQCkWoxt/0vsQvZswzTHUVOImccYmSyhJTp7kGtPed0Qcx8rK9h9YEgx+" crossorigin="anonymous"></script>
<!-- Bootstrap 5.3 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

<!--<link rel="stylesheet" href="../../public/css/style.css">-->
    <link rel="stylesheet" href="../projet/css/event.css">
 
    <title>Document</title>
</head>
<b style="background: url('../backoffice/cinema.jpg') no-repeat center center fixed; background-size: cover;">
  <header>
    <div class="menu-bar">
        <div class="netflixLogo">
            <a id="logo" href="#home">
                <img src="../projet/assets/imgs/logo.png" alt="Logo Image" id="logo1">
            </a>
        </div>    

        <ul>
            <li><a href="../projet/page.html">Home</a></li>
            <li><a href="#">Catalog</a></li>
            <li>
                <a href="../projet/event.php">Events <i class="fas fa-caret-down"></i></a>
                <div class="dropdown-menu">
                    <ul>
                        <li><a href="./historique.html">History</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="#">Purchases</a></li>
            <li><a href="#">Support</a></li>
        </ul>

        <nav class="sub-nav">
          <a href="#"><i class="fas fa-search sub-nav-logo"></i></a>
          <a href="#"><i class="fas fa-bell sub-nav-logo"></i></a>
          <a href="#"><i class="fas fa-user sub-nav-logo"></i></a> <!-- Account icon here -->
      </nav>
    </div>
</header>
<section id="fond2">
    <div id="hero-carousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
          </div>
        <div class="carousel-inner">
          <div class="carousel-item active c-item">
            <img src="../projet/assets/imgs/pexels-quark-studio-2507025_720x.webp" class="d-block w-100 c-img" alt="slide 1">
            
              <div class="carousel-caption top-0 mt-4 d-none d-md-block text-center">
                <p class="mt-5 fs-3 text-uppercase text-warning" style="font-family: 'Arial', sans-serif;">Watch Movies Under the Stars</p>
                <h1 class="display-5 fw-bolder text-capitalize text-light" style="font-family: 'Roboto', sans-serif;">
                  Bring a blanket, grab some snacks, and enjoy a magical outdoor cinema experience.
                </h1>
                
              </div>
              
          </div>
          <div class="carousel-item c-item">
            <img src="../projet/assets/imgs/popcorn.jpg" class="d-block w-100 c-img" alt="slide 2">
            <div class="carousel-caption top-0 mt-4 d-none d-md-block text-center">
                <p class="mt-5 fs-3 text-uppercase text-warning" style="font-family: 'Arial', sans-serif;">Snacks, Lights, Action!</p>
                <h1 class="display-5 fw-bolder text-capitalize text-light" style="font-family: 'Roboto', sans-serif;">
                    Grab your favorite treats and enjoy the perfect movie night atmosphere.
                </h1>
               
              </div>
              
          </div>
          <div class="carousel-item c-item">
            <img src="../projet/assets/imgs/peoplewatching.webp" class="d-block w-100 c-img" alt="slide 3">
            <div class="carousel-caption top-0 mt-4 d-none d-md-block text-center">
                <p class="mt-5 fs-3 text-uppercase text-warning" style="font-family: 'Arial', sans-serif; letter-spacing: 2px; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);">
                  Capture Moments, Create Memories
                </p>
                <h1 class="display-4 fw-bolder text-capitalize text-light" style="font-family: 'Roboto', sans-serif; line-height: 1.4; letter-spacing: 1px; text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.7);">
                  Your next favorite memory starts here.
                  Check Out Our Exciting Events!
                </h1>
              </div>
              
              
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#hero-carousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#hero-carousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
      </div>

      <div class="events ">
        <h5>Explore Our Upcoming Events!</h5>
      </div>

     
      <div class="container">
   <input type="hidden" id="id_client" value="<?= $id_client ?>">

   <div class="box-container">
      <?php
      $sql = "SELECT event.*, film.title, film.photo_path 
              FROM event 
              JOIN film ON event.id_film = film.id_film";
      $stmt = $conn->query($sql);
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      ?>
      <div class="box">
         <div class="image">
            <img src="<?= $row['photo_path'] ?>" alt="Event Image">
         </div>
         <div class="content">
            <h3><?= $row['name_event'] ?></h3>
            <p><strong>Film Title:</strong> <?= $row['title'] ?></p>
            <a href="#" class="btn" >Read More</a>
            <div class="event-details" >
    <p><strong>Description:</strong> <?= $row['description'] ?></p>
    <p><strong>Price:</strong> <?= $row['price_event'] ?> DT</p>
  
    <p><strong>Date:</strong> <?= $row['date_event'] ?></p> 
    <p><strong>Location:</strong> <?= $row['location'] ?></p>
    <p><strong>Total Places:</strong> <?= $row['total_places'] ?></p>
    <button onclick='showReservationForm(<?= json_encode($row) ?>)'>Reserve NOW</button>
</div>
         </div>
      </div>
      <?php } ?>
   </div>
</div>


<!-- Reservation Form (Initially Hidden) -->
<?php

require_once '../../controllers/eventcontroller.php';


if (isset($_POST["event_id"])) {
  $eventId = $_POST['event_id'];
    $eventController = new EventController();
    $result=$eventController->placeAvailability($eventId);
}
  
  
?>


<div id="reservationForm" class="reservation-form" style="display: none;">
  <div class="form-container">
    <span class="close-btn" onclick="closeReservationForm()">&times;</span>
    <h2>Reserve Your Spot</h2>
    
    <form action="add_reservation.php" method="POST" id="reservationFormContent">
      <input type="hidden" id="eventId" name="event_id">

      <label for="name">Name:</label>
      <input type="text" id="name" name="name" disabled value="Mira">

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" disabled value="mirabk@gmail.com">

      <label for="phone">Phone:</label>
      <input type="text" id="phone" name="phone" disabled value="123654789">
      <input type="hidden" id="id_client" name="id_client" value="<?= $id_client ?>">
      <label for="type_reservation">Type of Reservation:</label>
      <select id="type_reservation" name="type_reservation" onchange="updatePrice()">
        <option value="vip">VIP</option>
        <option value="standard">Standard</option>
        <option value="premium">Premium</option>
        <option value="special_event">Special Event</option>
      </select>

      <label for="people">Number of Tickets:</label>
      <input type="number" action="add_reservation.php" method="POST"  id="people" name="num_people" value="1" min="1" onchange="updatePrice()" required>

      <p id="errorMessage" style="color:red; display:none;">No available spots for this reservation.</p>
      
      <p>  <span id="notavailableplace"></span></p>
      <p>Date: <span id="eventDate"></span></p>
      <p>Price: <span id="price"></span> DT</p>
      <input type="hidden" id="price_input" name="price"/>

      <button type="submit" id="submit_button" name="submit" >Submit Reservation</button>
    </form>
</div>
</div>

    <!-- Success Message -->
    <div id="successMessage" style="display:none; text-align:center; font-size:18px; color:#4CAF50;">
        <p>Success! Your reservation has been successfully submitted.</p>
    </div>
</div>

     

        <div class="content-box">
            <div class="projection-grid">
              <!-- Introduction -->
              <div class="grid-item intro">
                <h2>Key Figures of Our Projections</h2>
                <p class="lead">
                  Our commitment to innovation, performance, and outdoor cinematic experiences drives us to excel in organizing cultural events.
                </p>
              </div>
        
              <!-- First Stat Block -->
              <div class="grid-item stat-block">
                <p class="stat-number">500,000 Viewers</p>
                <p>
                  Our viewers have enjoyed unforgettable moments through our unique and immersive film screenings.
                </p>
                <div class="progress-bar-container">
                  <div class="progress-bar" style="width: 80%"></div>
                </div>
              </div>
        
              <!-- Second Stat Block -->
              <div class="grid-item stat-block">
                <p class="stat-number">+300,000</p>
                <p>
                  We're proud to have welcomed over 50,000 happy attendees at our open-air film screenings.
                </p>
                <div class="progress-bar-container">
                  <div class="progress-bar" style="width: 45%"></div>
                </div>
              </div>
        
              <!-- Donut Chart Block -->
              <div class="grid-item chart-block">
                <canvas class="donut-chart"></canvas>
                <p class="chart-percentage">75%</p>
                <p class="chart-description">
                  80% of our audience returns every summer, showing their love for our outdoor screenings.
                </p>
              </div>
            </div>
          </div>

</section>

 
  
  
     
  
</body>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="./js/event.js"></script>



<script>
 

/*function toggleDetails(row, btn) {
   const details = btn.parentElement.querySelector('.event-details');
   details.style.display = details.style.display === 'none' ? 'block' : 'none';
   btn.textContent = details.style.display === 'block' ? 'Hide Details' : 'Read More';
}

let currentItem = 3;
const boxes = [...document.querySelectorAll('.box-container .box')];
//const loadMoreBtn = document.getElementById('load-more');
const loadMoreBtn = btn.querySelector('#load-more');
loadMoreBtn.style.display = 'inline-block';

loadMoreBtn.onclick = () => {
  for (let i = currentItem; i < currentItem + 3; i++) {
    if (boxes[i]) {
      boxes[i].style.display = 'inline-block';
    }
  }
  currentItem += 3;

  if (currentItem >= boxes.length) {
    loadMoreBtn.style.display = 'none';
  }
};*/

document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.btn').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      const box = this.closest('.box');
      const details = box.querySelector('.event-details');
      const isVisible = details.classList.contains('visible');

      details.classList.toggle('visible');
      this.textContent = isVisible ? 'Read More' : 'Hide Details';
    });
  });
});
</script>


  

  











</html>