<?php

require_once '../../controllers/Reservcontroller.php';


if (isset($_GET['id']) && !empty($_GET['id'])) {
    $reservController = new ReservController();
    $reservController->deleteReservation($_GET['id']);  // Call the deleteReservation method with the provided ID
    header('Location: historique.php?msg=Reservation deleted'); // Redirect to the index page with a success message
    exit;
} else {
    echo "Missing event ID!";
}
?>