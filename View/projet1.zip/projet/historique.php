<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"/>
    <link rel="stylesheet" href="his.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.min.js" integrity="sha384-VQqxDN0EQCkWoxt/0vsQvZswzTHUVOImccYmSyhJTp7kGtPed0Qcx8rK9h9YEgx+" crossorigin="anonymous"></script>
<!-- Bootstrap 5.3 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    h2 {
        text-align: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 28px;
        margin-top: 30px;
        margin-bottom: 20px;
        color: #333;
    }

    table {
        width: 90%;
        margin: 0 auto;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    th, td {
        padding: 12px 15px;
        text-align: center;
        border: 1px solid #ddd;
    }

    th {
        background-color: #007BFF;
        color: white;
        font-weight: 600;
        text-transform: uppercase;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #f1f1f1;
        cursor: pointer;
    }
</style>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="script.js">

    <link rel="stylesheet" href="../projet/css/his.css">
</head>
<body>
    <header>
        <div class="menu-bar">
            <div class="netflixLogo">
                <a id="logo" href="#home"><img src="../../public/img/logo.png" alt="Logo Image" id="logo1"></a>
             </div>    
            <ul>
              <li><a href="../projet/page.html">Home</a></li>
              <li><a href="#" >catalogue</a></li>
                <li><a href="./event.html">events <i class="fas fa-caret-down"></i></a>
                  <div class="dropdown-menu">
                      <ul>
                        <li><a href="./historique.php">historique</a></li>
                        
                      </ul>
                    </div>
              </li>
              <li><a href="#">achat </a>
              </li>
              <li><a href="#">reclamation</a></li>
            </ul>
            <nav class="sub-nav">
                <a href="#"><i class="fas fa-search sub-nav-logo"></i></a>
                <a href="#"><i class="fas fa-bell sub-nav-logo"></i></a>
                <a href="#">Account</a>        
              </nav>   


        </div>


          
    
    </header>
    
   <!-- Historique Table to display reservations -->
   <h2>Your Reservation History</h2>
   <table border="1">
       <thead>
           <tr>
               <th>Name</th>
               <th>Email</th>
               <th>Event Name</th>
               <th>Reservation Type</th>
               <th>Reservation Date</th>
               <th>Number of Tickets</th>
               <th>Total Price (DT)</th>
                <th>State</th>
                
           </tr>
       </thead>
       <tbody>
       <?php
       
                  require_once  '../../config/database.php';
                  require_once  '../../controllers/Reservcontroller.php';


             
                  $sql = "SELECT id_reserv,user.name,email,name_event,reservation.type,date_reserv,nb_people,price,reservation.state FROM user INNER JOIN reservation ON user.id_user = reservation.user_id INNER JOIN event ON event.id_event = reservation.event_id";
                  $conn = config::getConnexion();

                  $stmt = $conn->query($sql);
                  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                  ?>
                    <tr>
                      <td><?= htmlspecialchars($row["name"]) ?></td>
                      <td><?= htmlspecialchars($row["email"]) ?></td>
                      <td><?= htmlspecialchars($row["name_event"]) ?></td>
                      <td><?= htmlspecialchars($row["type"]) ?></td>
                      <td><?= htmlspecialchars($row["date_reserv"]) ?> </td> <!-- Price with DT -->
                      <td><?= htmlspecialchars($row["nb_people"]) ?></td>
                     
                      <td><?= htmlspecialchars($row["price"]) ?></td>
                      <td><?= htmlspecialchars($row["state"]) ?></td>
                      <td>
                       
                        <a href="cancel_reservation.php?id=<?= $row["id_reserv"] ?>" class="link-dark"><i class="fa-solid fa-trash fs-5"></i></a>]
                      </td>
                    </tr>
                  <?php } ?>
                
       </tbody>
   </table>
  

<script src="script.js"></script>

</body>
</html>